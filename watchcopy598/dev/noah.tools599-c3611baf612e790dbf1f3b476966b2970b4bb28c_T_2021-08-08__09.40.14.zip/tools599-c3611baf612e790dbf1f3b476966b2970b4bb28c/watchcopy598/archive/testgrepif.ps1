
# David Gleba # 2021-07-08

# :: prep ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# run this once..
# 		mkdir C:\temp


# :: Functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Function dg1 {

    }




# :: Main ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Watch this folder, then copy it..
Register-Watcher $watchedfolder
